# GUET-Android-GGmusic

## introduction

本项目是一个GUET-三院的安卓课程实验项目————GGmusic。

## usage
使用`Android Studio`, virtual drive使用`Resizable(Experimental) API 34`.

将在PC上的歌曲直接拖动到虚拟设备中, 在设备中`storage`的`Download`文件夹下找到歌曲, 并将其移动至虚拟SD卡下的`Music`目录.

## warning
歌曲格式只能是`mp3`, 并且某些mp3格式的歌曲是`X-mpeg`形式, 这种形式的歌曲不是标准的mp3格式, 需要将其转换成标准mp3格式才能播放.
